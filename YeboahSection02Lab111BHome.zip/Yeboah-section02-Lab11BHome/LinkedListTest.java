import java.util.Random;
import java.util.Scanner;
import java.io.*;

/**
 *  LINKED LIST  : Create a List Randomly and Automatically
 *                 Put PRINT/SUM/MAX in separate methods
 */
public class LinkedListTest
{
    // let the user enter N (the number of nodes)
    // generate a linked list of N nodes where data are random integers 
public int data;
Node link;
public int entry;
    public static Node ListGenerator()
    {
        // Generate RANDOM List
        int j, cint, size;
       
        // ...
        
        for (j = 1; j <= size; j++)
        {
        // ...
        }     
        
        // ...  
    }
    
    // print data of all nodes in the list (entry) 
    public static void ListPrint(Node entry)
    {
       //Standard method to PRINT/visit ALL NODES 
       // ...
       if(entry == null) {
           return;
        }
        Node temp = entry;
       while(temp != null){
            System.out.println(temp.data);
                if(temp.link != null) {
                    temp = temp.link;
                }
            else {
                return;
            }
       }
    }

    // find the largest data of all nodes in the list (entry), return it 
    public static int FindListMAX(Node entry)
    {
        // ...
        Node node = new Node(data);
        if(entry == null) {
            return -1;
        }
        
        else{ 
            int max = 0;
            if(entry.link <= max.ndata) {
                return max;
            }
            else {
                return -1;
            }
        }
    }    

    // find the SUM of all nodes in the list (entry), return it     
    public static int FindListSUM(Node entry)
    {
        // ...
    }     
    
    public static void main(String[] arg)
    {
        // ...

        // Generate RANDOM List
        entry=ListGenerator();        
              
        //Standard method to PRINT/visit ALL NODES 
        ListPrint(entry);
        
        //Calculate the SUM of ALL NODES
        sum=FindListSUM(entry);
        
        //find MAX in a LINKED LIST
        max=FindListMAX(entry);
        
    }
}