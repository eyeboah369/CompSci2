import java.util.Scanner;

public class sorting {
   public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        System.out.print("Enter list: ");
        int[] x = new int[input.nextInt()];
        for(int i = 0; i < x.length; i++) {
        x[i] = input.nextInt();
    }   
        System.out.println("The list is " + (checkSort(x) ? "already" : "not") + " sorted.");
    }
    
    public static boolean checkSort(int[] a) {
        int num = 1;
        for(int i = 0; i < a.length-1; i++) {

                if(a[i] > a[num]) {
                    return false;
                }
            }
        
        return true;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
