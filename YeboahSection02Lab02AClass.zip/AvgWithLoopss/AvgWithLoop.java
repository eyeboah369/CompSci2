import java.util.Scanner;

public class AvgWithLoop 
{
	public static void main (String[] args) 
	{
		
		
		Scanner input = new Scanner(System.in);

		
		int positives = 0;
		int negatives = 0;
		double count = 0;
		double avg = 0;
		
		System.out.print("Enter an integer, the input ends if it is 0:");
		
		for(int x  = input.nextInt() ; x != 0; x = input.nextInt()) {
			
			
			
			if (x > 0)
			{
				positives += 1;
				
			}
			else  
			{
				negatives += 1;
			
				
			}
			
		
			
			count += x;
			
			
			
			
			
			
			
		}
		avg = (count) / (avg + positives + negatives); 
			
		
		
	

		System.out.println("The number of positives is " + positives);
		System.out.println("The number of negatives is " + negatives);
		System.out.println("The total is " + count);
		System.out.printf("The average is " + "%.2f" ,avg);
		
		
		
	}
}