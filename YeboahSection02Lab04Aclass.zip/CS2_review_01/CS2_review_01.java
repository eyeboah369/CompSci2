import java.util.Scanner;

public class CS2_review_01
{
  public static void main (String[] args) {   
      
      int N = 0;
   
      standardI(N);
      
      standardIf(N);
      standardIfElse(N);
      standardNested(N);
      standardSwitch(N);
      standardWhile(N);
      standardDo(N);
      standardFor(N);
       
      
     
     
      
      
    }  /* Question 1 */  
    
    
   public static void standardI (int N) {
           Scanner input = new Scanner(System.in);
      System.out.print("Enter a positive integer:");    /* Question 2 */
      N = input.nextInt();
     
       standardO(N);
       
    }
      
    public static void standardO(int N) {
      System.out.println(N) ;                        /* Question 3 */
      standardIf(N);
      
    }
      
    public static void standardIf(int N) {
      if (N > 5) {                                  /*Question 4*/
          System.out.println("Your number is greater than 5");
        }
        standardIfElse(N);
       
    }
    
    public static void standardIfElse(int N) {
           if (N > 5) {                                
          System.out.println("Your number is greater than 5");
          
          if(N == 7) {                                  /*Question 5/6*/
              System.out.println("Your number is specifically 7");
            }
            standardNested(N);
        }
        
       
    }
    
    
    public static void standardNested(int N) {
       if (N == 5) {                            /*Question 5*/
           System.out.println("Your number is  5");
        }
           else {                                  /*Question 5/6*/
               System.out.println("Your number is greater than 5");
            }
           
        }
    
        
         public static void standardSwitch(int N) { 
        String words = " ";
        
        switch(N) {                                 /*Question 7*/
            case 1: words = "Your number is 1";
          
            
            case 2: words = "Your number is 2";
            break;
            
            case 3: words = "Your number is 3";
            break;
            
            case 4: words = "Your number is 4";
            break;
            
            case 5: words = "Your number is 5";
            break;
        }
       standardWhile(N);
    }
    
    public static int standardWhile(int N) {  
        int count = 0;
        while (count < N) {                           /*Question 8*/
            System.out.println("count is still less than N using a while loop");
            count++;
        }
        standardDo(N);
        return N;
        
    }
    
     public static int standardDo(int N) {
        int count = 0;
         do {
              System.out.println("N is still less than 15 using a do loop");
            count++;
        }
        while (count < N); 
        standardFor(N);
        return N;
    }
    
    public static int standardFor(int N) {
        for(int i = 0; i < N; i++) {
            System.out.println("i is still less than N");  
      
    }
   
    return N;
}

    
      
        
      
    



}


