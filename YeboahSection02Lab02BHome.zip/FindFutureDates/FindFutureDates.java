import java.util.Scanner;

public class FindFutureDates {
	public static void main (String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.print("Enter today's day:");
		int day = input.nextInt();
		
		System.out.print("Enter the number of days elapsed since today:");
		int elapsed = input.nextInt();
		
		String dayString;
		switch(day) {
			case 1: dayString = "Monday";
				break;
			case 2: dayString = "Tuesday";
				break;
			case 3: dayString = "Wednesday";
				break;
			case 4: dayString = "Thursday";
				break;
			case 5: dayString = "Friday";
				break;
			case 6: dayString = "Saturday";
				break;
			case 0: dayString = "Sunday";
				break;
			default: dayString = " an invalid starting day. Today's day must be 0-6.";
			
		}
		
		
		String futureString;
		switch((day + elapsed) % (7)) {
			case 1: futureString = "Monday";
				break;
			case 2: futureString = "Tuesday";
				break;
			case 3: futureString = "Wednesday";
				break;
			case 4: futureString = "Thursday";
				break;
			case 5: futureString = "Friday";
				break;
			case 6: futureString = "Saturday";
				break;
			case 0: futureString = "Sunday";
				break;
			default: futureString = "";
			
		}
			
			
			
			System.out.print("Today is " + dayString + " and the future day is " + futureString);
		
							   }
							   }