import java.util.Scanner;
public class SumMajorDiagonal {
	
	public static double sumMajorDiagonal(double[][] m) {
				double sum = 0.0;
		
			for(int i = 0; i <= m.length-1; i++) {
				sum = sum + m[i][i];
				
			}
			return sum;
	}
	
	
	
	public static void main (String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.print("Enter dimension n of nxn matrix:");
		int dimension = input.nextInt();
		
		double[][] rows = new double[dimension][dimension];
		

		for(int i = 0; i <= rows.length-1; i++) {
				
			System.out.print("Enter row " + i + ":");
			
			
			for(int j = 0; j <= rows.length-1; j++) {
				
				
				rows[i][j] = input.nextDouble();
			}
		}
		
		
		
		System.out.printf("%.1f", sumMajorDiagonal(rows));
	}
	

	
	
	
	
	
}